var num = 60;

var x = [];

var y = [];

function setup() {
  
  createCanvas(600, 600);
  
  noStroke();
  
// in the setting up of the for loop, the increment has to be positive, if it is negative you will be placing array elements at positions which can't exist. There cannot be an array position below 0, array positions start at 0 and go up from there. Values in an array can be negative, but the number inside the [] is indicating the position in the array, not the value that is stored at that position. In this for loop, which runs 60 times, a value of 0 is being placed at all of the positions being created in the array, so x[0] = 0, x[1] = 0, x[2] = 0 etc. up to x[59] which is the last position, 60 values, stored at position 0 to postion 59. 

  for (var i = 0; i < num; i++){        
    
    x[i] = 0;
    
    y[i] = 0;
    
  }
}

function draw() {
  
  background(0);
  
   for (var i = num-1; i > 0; i--){
   
   x[i] = x[i-1];
   
   y[i] = y[i-1];
   
 }
   
  x[0] = mouseX;
  
  y[0] = mouseY;
  
  for (var i =0; i < num; i++) {
    
// the fill value has to be a number, so fill(i = 4) will not work, if you want to set the fill value at 4 then you would write fill(4); if you want to use the increment of the for loop as part of the equation to create a number value, then you could write something like fill(i + 4); or fill(i *4); etc. 

    fill(i);
    
// here is where you would use draw functions to create a pumpkin. In this example one ellipse is created, but more lines of code can be included to create a shape or collection of shapes before the closing }
  
    
    pumpkin(x[i], y[i], 0, 0);
    
    


  }

}
function pumpkin(x, y){
    push();
  
  translate(x, y);
  
  fill(6,173,35,96);
rect(185, 110, 30, 30);  
  
ellipseMode(CENTER);
fill(250,106, 12, 98);
ellipse(200, 200, 170, 120);
  
///tri
    fill(0)
  triangle(150, 185, 165, 185, 158, 165);
    fill(0)
  triangle(250, 185, 235, 185, 238, 165);
    fill(0)
  triangle(195, 210, 210, 210, 200, 185); 
  
  arc(200, 220, 80, 50,0, PI);
  
  pop();
  
}
