let img; 
let imgDragon;
let imgDragonFly;
let c;

function preload(){
  
  imgDragon = loadImage('Pix/Dragon.png');
  imgDragonFly = loadImage('Pix/DragonFly.png');
  imgDragon.loadPixels();
  imgDragonFly.loadPixels();

}

function setup(){

createCanvas(600, 600);
}

function draw(){
  background(220);
  
  textFont("Georgia");
  
  text("Dragons", 300, 70 ,170, 100);
  
  image(imgDragon, 50, mouseY, 70, 50)
    
  image(imgDragon, 300, mouseY-100, 170, 150)
  
  image(imgDragonFly, 200, mouseX-20)

}