function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(50);
  
  storm(110, 110)
  
  storm(1, 120)
  
  storm(250, 110)
   
  
  
}

function storm(x, y) {
  
  push();
  
  translate(x, y);

  stroke(170); 

  strokeWeight(70);

  line(100, 5, 0, 5);

  noStroke();

  fill(170);

  ellipse(15, -25, 65, 65);

  ellipse(50, -45, 65, 65);
  
  ellipse(85, -25, 65, 65);

  

  fill(120);

  ellipse(65, -5, 65, 65);

  ellipse(100, -25, 65, 65);
  
  ellipse(135, -5, 65, 65);
  
  stroke(120); 

  strokeWeight(70);
  
  line(55, 20, 145, 20)


  pop();
  
}

